import os
import yaml
import faiss
from typing import List, Optional
from llama_index.core import VectorStoreIndex, StorageContext, load_index_from_storage
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.vector_stores.faiss import FaissVectorStore
from llama_index.core.schema import TextNode

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)


class VectorStoreManager:
    """Manages FAISS vector store with embedding and persistence."""
    
    def __init__(self, model_name="Qwen/Qwen3-Embedding-0.6B", persist_dir="./res/storage"):
        """
        Initialize the vector store manager.
        
        Args:
            model_name: HuggingFace model for embeddings (must match chunking model)
            persist_dir: Directory to save/load the FAISS index
        """
        self.model_name = model_name
        self.persist_dir = persist_dir
        self.embed_model = None
        self._index = None
    
    def _initialize_embedding_model(self):
        """Lazy initialization of embedding model."""
        if self.embed_model is None:
            print(f"Loading embedding model: {self.model_name}...")
            self.embed_model = HuggingFaceEmbedding(model_name=self.model_name)
            print("✓ Embedding model loaded")
    
    def index_exists(self) -> bool:
        """Check if a persisted index exists."""
        # Check for the main index files
        docstore_path = os.path.join(self.persist_dir, "docstore.json")
        vector_store_path = os.path.join(self.persist_dir, "default__vector_store.json")
        return os.path.exists(docstore_path) and os.path.exists(vector_store_path)
    
    def create_and_save_index(self, nodes: List[TextNode], force_rebuild: bool = False) -> VectorStoreIndex:
        """
        Create FAISS index from nodes and persist to disk.
        
        Args:
            nodes: List of text nodes (chunks) to embed and index
            force_rebuild: If True, rebuild even if index exists
            
        Returns:
            VectorStoreIndex instance
        """
        # Check if index already exists
        if not force_rebuild and self.index_exists():
            print("Existing index found, loading instead of rebuilding...")
            return self.load_existing_index()
        
        # Initialize embedding model
        self._initialize_embedding_model()
        
        print(f"Creating FAISS index for {len(nodes)} chunks...")
        
        d = CONFIG['embeddings']['dimension']
        faiss_index = faiss.IndexFlatL2(d)
        
        # Create vector store
        vector_store = FaissVectorStore(faiss_index=faiss_index)
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        
        index = VectorStoreIndex(
            nodes, 
            storage_context=storage_context, 
            embed_model=self.embed_model,
            show_progress=CONFIG['vector_store']['show_progress']
        )
        print(f"✓ Index created with {len(nodes)} vectors")
        
        # Persist to disk
        print(f"Saving index to {self.persist_dir}...")
        os.makedirs(self.persist_dir, exist_ok=True)
        index.storage_context.persist(persist_dir=self.persist_dir)
        print("✓ Index saved successfully")
        
        self._index = index
        return index
    
    def load_existing_index(self) -> Optional[VectorStoreIndex]:
        """Load index from disk."""
        if not self.index_exists():
            print(f"No existing index found at {self.persist_dir}")
            return None
        
        print(f"Loading existing index from {self.persist_dir}...")
        
        # Initialize embedding model
        self._initialize_embedding_model()
        
        try:
            # Load vector store
            vector_store = FaissVectorStore.from_persist_dir(self.persist_dir)
            storage_context = StorageContext.from_defaults(
                vector_store=vector_store, 
                persist_dir=self.persist_dir
            )
            
            # Load index
            index = load_index_from_storage(
                storage_context, 
                embed_model=self.embed_model
            )
            print("✓ Index loaded successfully")
            
            self._index = index
            return index
            
        except Exception as e:
            print(f"✗ Error loading index: {e}")
            return None
    
    def get_or_create_index(self, nodes: List[TextNode], force_rebuild: bool = False) -> VectorStoreIndex:
        """
        Convenience method to get index (load if exists, create if not).
        
        Args:
            nodes: Nodes to index (only used if creating new index)
            force_rebuild: Force rebuild even if index exists
            
        Returns:
            VectorStoreIndex instance
        """
        if not force_rebuild and self.index_exists():
            return self.load_existing_index()
        else:
            return self.create_and_save_index(nodes, force_rebuild)
    
    @property
    def index(self) -> Optional[VectorStoreIndex]:
        """Get the current index instance."""
        return self._index