import os
import pickle
import yaml
from typing import List, Optional
from llama_index.core.node_parser import SemanticSplitterNodeParser
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import SimpleDirectoryReader
from llama_index.core.schema import TextNode

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)


class GloomhavenPDFProcessor:
    """Handles PDF loading and semantic chunking with persistence."""
    
    def __init__(self, model_name="Qwen/Qwen3-Embedding-0.6B", chunks_path="./res/chunks.pkl", max_pages=None):
        """
        Initialize the PDF processor.
        
        Args:
            model_name: HuggingFace model for semantic embeddings
            chunks_path: Path to save/load processed chunks
            max_pages: Maximum number of pages to process (None = all pages)
        """
        self.model_name = model_name
        self.chunks_path = chunks_path
        self.max_pages = max_pages
        self.embed_model = None
        self.splitter = None
    
    def _initialize_models(self):
        """Lazy initialization of embedding model and splitter."""
        if self.embed_model is None:
            print(f"Loading embedding model: {self.model_name}...")
            self.embed_model = HuggingFaceEmbedding(model_name=self.model_name)
            print("✓ Embedding model loaded")
        
        if self.splitter is None:
            print("Initializing semantic splitter...")
            self.splitter = SemanticSplitterNodeParser(
                buffer_size=CONFIG['semantic_splitter']['buffer_size'], 
                breakpoint_percentile_threshold=CONFIG['semantic_splitter']['breakpoint_percentile_threshold'], 
                embed_model=self.embed_model
            )
            print("✓ Semantic splitter ready")
    
    def chunks_exist(self) -> bool:
        """Check if processed chunks already exist on disk."""
        return os.path.exists(self.chunks_path)
    
    def save_chunks(self, nodes: List[TextNode]) -> None:
        """Save processed chunks to disk."""
        os.makedirs(os.path.dirname(self.chunks_path), exist_ok=True)
        
        print(f"Saving {len(nodes)} chunks to {self.chunks_path}...")
        with open(self.chunks_path, 'wb') as f:
            pickle.dump(nodes, f)
        print(f"✓ Chunks saved successfully")
    
    def load_chunks(self) -> Optional[List[TextNode]]:
        """Load previously processed chunks from disk."""
        if not self.chunks_exist():
            print(f"No existing chunks found at {self.chunks_path}")
            return None
        
        print(f"Loading existing chunks from {self.chunks_path}...")
        try:
            with open(self.chunks_path, 'rb') as f:
                nodes = pickle.load(f)
            print(f"✓ Loaded {len(nodes)} chunks from disk")
            return nodes
        except Exception as e:
            print(f"✗ Error loading chunks: {e}")
            return None
    
    def process_full_rulebook(self, file_path: str, force_reprocess: bool = False) -> List[TextNode]:
        """
        Load and process the rulebook with semantic chunking.
        
        Args:
            file_path: Path to the PDF file
            force_reprocess: If True, reprocess even if chunks exist
            
        Returns:
            List of text nodes (chunks)
        """
        # Check if chunks already exist
        if not force_reprocess and self.chunks_exist():
            print("Existing chunks found, loading from disk...")
            return self.load_chunks()
        
        # Verify PDF exists
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"PDF not found at {file_path}")
        
        # Initialize models
        self._initialize_models()
        
        # Load PDF
        print(f"Loading PDF from {file_path}...")
        documents = SimpleDirectoryReader(input_files=[file_path]).load_data()
        print(f"✓ Loaded {len(documents)} document(s)")
        
        if self.max_pages is not None and self.max_pages > 0:
            print(f"Limiting to first {self.max_pages} pages...")
            full_text = "\n\n".join([doc.text for doc in documents])
            
            if len(documents) > self.max_pages:
                documents = documents[:self.max_pages]
                print(f"✓ Using only first {self.max_pages} pages")
            else:
                print(f"✓ PDF has {len(documents)} pages (less than {self.max_pages}), using all")
        
        print("Performing semantic chunking...")
        nodes = self.splitter.get_nodes_from_documents(documents)
        print(f"✓ Created {len(nodes)} semantic chunks")
        
        # Save chunks for future use
        self.save_chunks(nodes)
        
        return nodes
    
    def get_or_create_chunks(self, file_path: str, force_reprocess: bool = False) -> List[TextNode]:
        """Convenience method to get chunks (load if exist, create if not)."""
        return self.process_full_rulebook(file_path, force_reprocess)