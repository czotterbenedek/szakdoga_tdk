#!/usr/bin/env python
"""
Author: Benedek Czotter
"""

import os
import sys
import yaml
import requests
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.tools.pdf_processor import GloomhavenPDFProcessor
from src.tools.vector_store import VectorStoreManager
from src.agents.graph import GloomhavenRulesGraph

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)

RULEBOOK_URL = CONFIG['pdf']['url']
PDF_PATH = CONFIG['paths']['rulebook_pdf']
CHUNKS_PATH = CONFIG['paths']['chunks_cache']
STORAGE_DIR = CONFIG['paths']['vector_storage']
EMBEDDING_MODEL = CONFIG['embeddings']['model_name']
MAX_PAGES = CONFIG['pdf']['max_pages']


def download_pdf(url: str, save_path: str) -> bool:
    """Download the rulebook PDF if it doesn't exist."""
    if os.path.exists(save_path):
        print(f"✓ PDF already exists at {save_path}")
        return True
    
    print(f"Downloading rulebook from {url}...")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    
    try:
        response = requests.get(url, stream=True, timeout=CONFIG['http']['timeout'])
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        
        with open(save_path, 'wb') as f:
            downloaded = 0
            for chunk in response.iter_content(chunk_size=CONFIG['http']['chunk_size']):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
        
        print(f"✓ PDF downloaded to {save_path}")
        return True
        
    except Exception as e:
        print(f"✗ Error downloading PDF: {e}")
        return False


def initialize_system(force_rebuild: bool = False):
    """
    Initialize the complete system with proper caching.
    
    Args:
        force_rebuild: If True, rebuild everything from scratch
    
    Returns:
        VectorStoreIndex ready for querying
    """
    print("="*70)
    print("GLOOMHAVEN RULES AGENT - INITIALIZATION")
    print("="*70)
    
    print("\n[1/3] Checking for rulebook PDF...")
    if not download_pdf(RULEBOOK_URL, PDF_PATH):
        raise FileNotFoundError("Unable to obtain rulebook PDF")
    
    print("\n[2/3] Processing semantic chunks...")
    pdf_processor = GloomhavenPDFProcessor(
        model_name=EMBEDDING_MODEL,
        chunks_path=CHUNKS_PATH,
        max_pages=MAX_PAGES
    )
    
    nodes = pdf_processor.get_or_create_chunks(PDF_PATH, force_reprocess=force_rebuild)
    
    if nodes is None or len(nodes) == 0:
        raise ValueError("Failed to create or load chunks")
    
    print(f"✓ Ready with {len(nodes)} semantic chunks")
    
    print("\n[3/3] Building FAISS vector index...")
    vector_manager = VectorStoreManager(
        model_name=EMBEDDING_MODEL,
        persist_dir=STORAGE_DIR
    )
    
    index = vector_manager.get_or_create_index(nodes, force_rebuild=force_rebuild)
    
    if index is None:
        raise ValueError("Failed to create or load vector index")
    
    print("\n" + "="*70)
    print("✓ SYSTEM READY")
    print("="*70)
    
    return index


def main(force_rebuild: bool = False):
    """
    Main entry point.
    
    Args:
        force_rebuild: Force rebuild all artifacts
    
    Returns:
        Initialized vector index
    """
    try:
        index = initialize_system(force_rebuild=force_rebuild)
        
        # Initialize the LangGraph workflow
        print("\n" + "="*70)
        print("INITIALIZING LANGGRAPH WORKFLOW")
        print("="*70)
        
        graph = GloomhavenRulesGraph(index)
        print("✓ LangGraph workflow initialized")
        
        # Save graph visualization
        graph.save_graph_image("docs/agent_graph.png")
        
        # Test with sample questions
        print("\n" + "="*70)
        print("TESTING WITH SAMPLE QUESTIONS")
        print("="*70)
        
        test_questions = [
            "What happens when a character's hand is empty?",
            "Can I move through enemies?",
            "What is the capital of France?"  # Irrelevant question
        ]
        
        for question in test_questions:
            try:
                answer = graph.query(question)
            except Exception as e:
                print(f"Error processing question '{question}': {e}")
        
        print("="*70)
        print("✓ SYSTEM FULLY OPERATIONAL")
        print("="*70)
        
        return graph
        
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    
    game_graph = main()