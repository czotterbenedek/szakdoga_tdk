import yaml
from typing import Dict, Any

from src.agents.base_agent import LLMAgent
from src.agents.schemas import AgentState

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)


class VerifierAgent(LLMAgent):
    """Verifier agent that evaluates if retrieved chunks answer the question sufficiently."""
    
    def __init__(self, config_path: str = None):
        """Initialize the verifier agent with configuration.
        
        Args:
            config_path: Path to the verifier configuration YAML file (defaults to config.yaml value)
        """
        if config_path is None:
            config_path = CONFIG['agent_configs']['verifier']
        super().__init__(config_path, "verifier")
    
    def process(self, state: AgentState) -> AgentState:
        """Alias for verify_chunks to match base class interface."""
        return self.verify_chunks(state)
    
    def verify_chunks(self, state: AgentState) -> AgentState:
        """Verify if retrieved chunks sufficiently answer the question.
        
        Args:
            state: Current agent state with question and retrieved_chunks
            
        Returns:
            Updated state with chunks_sufficient and verification_score
        """
        user_question = state["user_question"]
        chunks = state.get("retrieved_chunks", [])
        
        if not chunks:
            # No chunks retrieved - definitely insufficient
            state["chunks_sufficient"] = False
            state["verification_score"] = 0.0
            state["current_agent"] = "verifier"
            self.log("No chunks retrieved - marking as insufficient")
            return state
        
        # Prepare context from chunks
        context = "\n\n".join([f"[Chunk {i+1}]: {chunk[:500]}" for i, chunk in enumerate(chunks)])
        
        # Build prompt with context
        user_input = f"""Question: {user_question}

Retrieved Content:
{context}

Evaluate if this content adequately answers the question."""
        
        prompt = self.build_prompt(user_input)
        
        # Generate response
        response_text = self.generate_response(prompt)
        
        # Parse JSON with fallback
        result = self.parse_json_response(
            response_text,
            self._fallback_verification,
            user_question,
            chunks
        )
        
        # Extract verification results
        is_sufficient = result.get("is_sufficient", False)
        quality_score = result.get("quality_score", 0.5)
        quality_threshold = self.config.get("quality_threshold", 0.6)
        
        # Override is_sufficient based on threshold
        is_sufficient = quality_score >= quality_threshold
        
        state["chunks_sufficient"] = is_sufficient
        state["verification_score"] = quality_score
        state["current_agent"] = "verifier"
        
        return state
    
    def _fallback_verification(self, question: str, chunks: list) -> Dict[str, Any]:
        """Simple heuristic-based verification fallback.
        
        Args:
            question: User's question
            chunks: Retrieved text chunks
            
        Returns:
            Verification result dictionary
        """
        question_words = set(question.lower().split())
        
        # Calculate overlap between question and chunks
        chunk_text = " ".join(chunks).lower()
        overlap = sum(1 for word in question_words if len(word) > 3 and word in chunk_text)
        
        quality_score = min(1.0, (overlap / max(1, len(question_words))) * 0.7 + 
                           (len(chunk_text) > 200) * 0.3)
        
        is_sufficient = quality_score >= 0.6
        
        return {
            "is_sufficient": is_sufficient,
            "quality_score": quality_score,
            "reasoning": f"Heuristic check: {overlap} relevant words found in chunks",
            "missing_info": "Specific details may be missing" if not is_sufficient else ""
        }
    
    def should_search_web(self, state: AgentState) -> str:
        """Routing function: determine if web search is needed.
        
        Args:
            state: Current agent state
            
        Returns:
            Next node name: "summary" if sufficient, "webscraper" if not
        """
        if state.get("chunks_sufficient", False):
            state["answer_source"] = "rulebook"
            return "summary"
        else:
            return "webscraper"
