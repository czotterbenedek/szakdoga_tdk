import yaml
from typing import Dict, Any, List

from src.agents.base_agent import LLMAgent
from src.agents.schemas import AgentState, StructuredAnswer, RuleCategory

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)


class SummaryAgent(LLMAgent):
    """Summary agent that generates structured answers based on retrieved context."""
    
    def __init__(self, config_path: str = None):
        """Initialize the summary agent with configuration.
        
        Args:
            config_path: Path to the summary configuration YAML file (defaults to config.yaml value)
        """
        if config_path is None:
            config_path = CONFIG['agent_configs']['summary']
        super().__init__(config_path, "summary")
    
    def process(self, state: AgentState) -> AgentState:
        """Alias for generate_answer to match base class interface."""
        return self.generate_answer(state)
    
    def generate_answer(self, state: AgentState) -> AgentState:
        """Generate a structured answer based on the question and optional context.
        
        Args:
            state: Current agent state with question, relevance, category, and optional chunks
            
        Returns:
            Updated state with explanation, is_played_correctly, and sources
        """
        user_question = state["user_question"]
        is_relevant = state.get("is_relevant", True)
        category = state.get("category", "Irrelevant")
        retrieved_chunks = state.get("retrieved_chunks", [])
        web_content = state.get("web_content", [])
        answer_source = state.get("answer_source", "rulebook")
        
        # Prepare context - prioritize rulebook, but use web if needed
        context = ""
        source_note = ""
        
        if retrieved_chunks and answer_source == "rulebook":
            context = "\n\n--- CONTEXT FROM RULEBOOK ---\n"
            for i, chunk in enumerate(retrieved_chunks, 1):
                context += f"\n[Chunk {i}]\n{chunk}\n"
            source_note = ""
        elif web_content:
            context = "\n\n--- CONTEXT FROM WEB SOURCES ---\n"
            for i, content in enumerate(web_content, 1):
                context += f"\n[Web Source {i}]\n{content}\n"
            source_note = "\n⚠️ NOTE: This information is from internet sources, not the official rulebook. Please verify with the official Gloomhaven rules."
        
        # Prepare the prompt
        if not is_relevant:
            prompt_text = f"User Question: {user_question}\n\nThis question is IRRELEVANT to Gloomhaven. Provide a polite rejection."
        else:
            prompt_text = f"User Question: {user_question}\n\nCategory: {category}\n{context}{source_note}"
        
        # Build and generate
        prompt = self.build_prompt(prompt_text)
        response_text = self.generate_response(prompt)
        
        # Parse JSON with fallback
        result = self.parse_json_response(
            response_text,
            self._fallback_answer,
            user_question, is_relevant, category, retrieved_chunks, state
        )
        
        # Update state
        state["explanation"] = result["explanation"]
        state["is_played_correctly"] = result.get("is_played_correctly")
        state["category"] = result.get("category", category)
        state["sources"] = result.get("sources", [])
        state["current_agent"] = "summary"
        
        return state
    
    def _fallback_answer(self, question: str, is_relevant: bool, category: str, chunks: List[str], state: AgentState = None) -> Dict[str, Any]:
        """Simple fallback answer generation."""
        if state and state.get("needs_clarification", False):
            clarification_prompt = state.get("clarification_prompt", "Could you please provide more context about your question?")
            return {
                "explanation": clarification_prompt,
                "is_played_correctly": None,
                "category": category,
                "sources": []
            }
        
        if not is_relevant:
            return {
                "explanation": "I apologize, but this question doesn't appear to be related to Gloomhaven board game rules. Please ask about game setup, combat, scenarios, or character abilities.",
                "is_played_correctly": None,
                "category": "Irrelevant",
                "sources": []
            }
        
        web_content = state.get("web_content", []) if state else []
        answer_source = state.get("answer_source", "rulebook") if state else "rulebook"
        
        if web_content and answer_source == "web":
            explanation = f"⚠️ Based on internet sources (not official rulebook): {web_content[0][:200]}..."
            sources = ["Internet sources"]
        elif chunks:
            explanation = f"Based on the rulebook: {chunks[0][:200]}..."
            sources = ["Rulebook excerpt"]
        else:
            explanation = f"This is a {category} question about Gloomhaven. Please refer to the official rulebook for detailed information."
            sources = []
        
        return {
            "explanation": explanation,
            "is_played_correctly": None,
            "category": category,
            "sources": sources
        }
    
    def format_output(self, state: AgentState) -> StructuredAnswer:
        """Format the agent state into a structured answer.
        
        Args:
            state: Final agent state
            
        Returns:
            StructuredAnswer object ready for output
        """
        return StructuredAnswer(
            explanation=state["explanation"],
            is_played_correctly=state["is_played_correctly"],
            category=RuleCategory(state["category"]),
            sources=state["sources"]
        )
