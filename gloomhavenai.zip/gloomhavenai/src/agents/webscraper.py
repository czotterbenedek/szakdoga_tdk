import yaml
import requests
from typing import Dict, Any, List
from bs4 import BeautifulSoup
from urllib.parse import quote_plus
import time

from src.agents.base_agent import BaseAgent
from src.agents.schemas import AgentState

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)


class WebScraperAgent(BaseAgent):
    """Web scraper agent that searches the internet for Gloomhaven rules information."""
    
    def __init__(self, config_path: str = None):
        """Initialize the web scraper agent with configuration.
        
        Args:
            config_path: Path to the webscraper configuration YAML file (defaults to config.yaml value)
        """
        if config_path is None:
            config_path = CONFIG['agent_configs']['webscraper']
        super().__init__(config_path, "webscraper")
    
    def process(self, state: AgentState) -> AgentState:
        """Alias for search_web to match base class interface."""
        return self.search_web(state)
    
    def search_web(self, state: AgentState) -> AgentState:
        """Search the web for information about the user's question.
        
        Args:
            state: Current agent state with question
            
        Returns:
            Updated state with web_content
        """
        user_question = state["user_question"]
        category = state.get("category", "")
        
        self.log(f"Searching web for: {user_question}")
        
        # Enhance query with "Gloomhaven"
        search_query = f"Gloomhaven {user_question}"
        
        # Search the web
        search_results = self._duckduckgo_search(search_query)
        
        # Extract content from results
        web_contents = []
        for url in search_results[:self.config.get("max_results", 3)]:
            content = self._extract_content(url)
            if content:
                web_contents.append(content)
        
        state["web_content"] = web_contents
        state["answer_source"] = "web"
        state["current_agent"] = "webscraper"
        
        return state
    
    def _duckduckgo_search(self, query: str) -> List[str]:
        """Perform a DuckDuckGo search and return URLs.
        
        Args:
            query: Search query
            
        Returns:
            List of URLs
        """
        try:
            search_url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
            
            headers = {
                "User-Agent": self.config.get("user_agent", "Mozilla/5.0")
            }
            
            response = requests.get(
                search_url, 
                headers=headers, 
                timeout=self.config.get("timeout", 10)
            )
            
            if response.status_code != 200:
                self.log(f"Search failed with status {response.status_code}")
                return []
            
            soup = BeautifulSoup(response.text, 'html.parser')
            results = []
            
            for result in soup.find_all('a', class_='result__a'):
                url = result.get('href')
                if url and url.startswith('http'):
                    trusted = any(domain in url for domain in self.config.get("trusted_domains", []))
                    if trusted:
                        results.insert(0, url)
                    else:
                        results.append(url)
            
            return results[:self.config.get("max_results", 3)]
            
        except Exception as e:
            self.log(f"Search error: {e}")
            return []
    
    def _extract_content(self, url: str) -> str:
        """Extract readable content from a webpage.
        
        Args:
            url: URL to extract content from
            
        Returns:
            Extracted text content
        """
        try:
            headers = {
                "User-Agent": self.config.get("user_agent", "Mozilla/5.0")
            }
            
            response = requests.get(
                url, 
                headers=headers, 
                timeout=self.config.get("timeout", 10)
            )
            
            if response.status_code != 200:
                return ""
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            for script in soup(["script", "style", "nav", "footer", "header"]):
                script.decompose()
            
            text = soup.get_text(separator=' ', strip=True)
            
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)
            
            max_length = self.config.get("max_content_length", 2000)
            if len(text) > max_length:
                text = text[:max_length] + "..."
            
            text = f"[Source: {url}]\n{text}"
            
            return text
            
        except Exception as e:
            self.log(f"Content extraction error from {url}: {e}")
            return ""
    
    def route_to_summary(self, state: AgentState) -> str:
        """Routing function: always go to summary after web scraping.
        
        Args:
            state: Current agent state
            
        Returns:
            Next node name: "summary"
        """
        return "summary"
