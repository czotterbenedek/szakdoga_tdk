import yaml
from typing import Dict, Any

from src.agents.base_agent import LLMAgent
from src.agents.schemas import AgentState, RuleCategory

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)


class SupervisorAgent(LLMAgent):
    """Supervisor agent that determines question relevance and categorization."""
    
    def __init__(self, config_path: str = None):
        """Initialize the supervisor agent with configuration.
        
        Args:
            config_path: Path to the supervisor configuration YAML file (defaults to config.yaml value)
        """
        if config_path is None:
            config_path = CONFIG['agent_configs']['supervisor']
        super().__init__(config_path, "supervisor")
    
    def process(self, state: AgentState) -> AgentState:
        """Alias for analyze_question to match base class interface."""
        return self.analyze_question(state)
    
    def analyze_question(self, state: AgentState) -> AgentState:
        """Analyze the user's question for relevance and category.
        
        Args:
            state: Current agent state containing user_question
            
        Returns:
            Updated state with is_relevant and category fields
        """
        user_question = state["user_question"]
        
        # Build prompt
        prompt = self.build_prompt(user_question)
        
        # Generate response
        response_text = self.generate_response(prompt)
        
        # Parse JSON with fallback
        result = self.parse_json_response(
            response_text,
            self._fallback_classification,
            user_question
        )
        
        # Check confidence level
        confidence = result.get("confidence", 1.0)
        confidence_threshold = self.config.get("confidence_threshold", 0.7)
        
        needs_clarification = confidence < confidence_threshold
        clarification_prompt = None
        
        if needs_clarification:
            clarification_prompt = self._generate_clarification_prompt(user_question, result)
            self.log(f"⚠️ Low confidence ({confidence:.2f}), requesting clarification")
        
        # Update state
        state["is_relevant"] = result["is_relevant"]
        state["category"] = result["category"]
        state["current_agent"] = "supervisor"
        state["confidence"] = confidence
        state["needs_clarification"] = needs_clarification
        state["clarification_prompt"] = clarification_prompt
        
        return state
    
    def _fallback_classification(self, question: str) -> Dict[str, Any]:
        """Simple keyword-based fallback classification."""
        question_lower = question.lower()
        
        gloomhaven_keywords = [
            "gloomhaven", "character", "combat", "attack", "move", "scenario",
            "monster", "card", "ability", "damage", "heal", "rest", "exhaust",
            "initiative", "treasure", "loot", "setup", "turn", "action", "modifier"
        ]
        
        keyword_matches = sum(1 for keyword in gloomhaven_keywords if keyword in question_lower)
        is_relevant = keyword_matches > 0
        
        if not is_relevant:
            return {
                "is_relevant": False,
                "category": "Irrelevant",
                "reasoning": "Question does not appear to be about Gloomhaven",
                "confidence": 0.9
            }
        
        category_scores = {
            "BoardGameSetup": sum(1 for word in ["setup", "prepare", "place", "component"] if word in question_lower),
            "Combat": sum(1 for word in ["attack", "damage", "combat", "monster", "initiative"] if word in question_lower),
            "Scenario": sum(1 for word in ["scenario", "objective", "treasure", "room"] if word in question_lower),
            "Character": sum(1 for word in ["character", "card", "ability", "rest", "exhaust"] if word in question_lower)
        }
        
        max_score = max(category_scores.values())
        
        if max_score == 0:
            category = "Character"
            confidence = 0.3
        else:
            category = max(category_scores, key=category_scores.get)
            total_matches = sum(category_scores.values())
            confidence = min(0.95, 0.5 + (max_score / max(1, total_matches)) * 0.5)
        
        return {
            "is_relevant": True,
            "category": category,
            "reasoning": "Classified using keyword matching",
            "confidence": confidence
        }
    
    def _generate_clarification_prompt(self, question: str, result: Dict[str, Any]) -> str:
        """Generate a clarification prompt for the user.
        
        Args:
            question: Original user question
            result: Classification result with low confidence
            
        Returns:
            Clarification prompt string
        """
        category = result.get("category", "Unknown")
        
        category_descriptions = {
            "BoardGameSetup": "game setup and preparation",
            "Combat": "combat mechanics and battles",
            "Scenario": "scenario objectives and progression",
            "Character": "character abilities and actions"
        }
        
        description = category_descriptions.get(category, "the rules")
        
        clarification = (
            f"I'm not entirely sure which aspect of Gloomhaven your question refers to. \n"
            f"I think it might be about {description}, but could you clarify? \n\n"
            f"Is your question about:\n"
            f"  1. Game setup and preparation\n"
            f"  2. Combat mechanics\n"
            f"  3. Scenario objectives\n"
            f"  4. Character abilities\n\n"
            f"Please specify or rephrase your question with more context."
        )
        
        return clarification
    
    def should_retrieve(self, state: AgentState) -> str:
        """Routing function: determine next node in the graph.
        
        Args:
            state: Current agent state
            
        Returns:
            Next node name: "retriever" if relevant, "summary" if not
        """
        # If needs clarification, go to summary to present clarification prompt
        if state.get("needs_clarification", False):
            return "summary"
        
        if state["is_relevant"]:
            return "retriever"
        else:
            return "summary"
