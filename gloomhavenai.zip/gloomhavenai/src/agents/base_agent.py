"""
Base Agent class for all agents in the system.
"""
import yaml
import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any, Optional
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch

from src.agents.schemas import AgentState


class BaseAgent(ABC):
    """Abstract base class for all agents in the Gloomhaven Rules system."""
    
    def __init__(self, config_path: str, config_key: str):
        self.config = self._load_config(config_path, config_key)
        self.agent_name = self.config.get("name", self.__class__.__name__)
        
    def _load_config(self, config_path: str, config_key: str) -> Dict[str, Any]:
        """Load configuration from YAML file.
        
        Args:
            config_path: Path to configuration file
            config_key: Key for this agent's configuration
            
        Returns:
            Configuration dictionary
        """
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        return config[config_key]
    
    def log(self, message: str):
        """Log a message with agent name prefix.
        
        Args:
            message: Message to log
        """
        print(f"[{self.agent_name}] {message}")
    
    @abstractmethod
    def process(self, state: AgentState) -> AgentState:
        """Process the agent state. Must be implemented by subclasses.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated agent state
        """
        pass


class LLMAgent(BaseAgent):
    """Base class for agents that use LLM models."""
    
    def __init__(self, config_path: str, config_key: str):
        """Initialize the LLM agent with model loading.
        
        Args:
            config_path: Path to the configuration YAML file
            config_key: Key in the YAML file for this agent's config
        """
        super().__init__(config_path, config_key)
        
        # Load LLM model
        self.device = self.config.get("device", "cpu")
        model_name = self.config.get("model")
        
        if model_name:
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name,
                torch_dtype=torch.float32,
                device_map=self.device
            )
        else:
            self.tokenizer = None
            self.model = None
    
    def generate_response(self, prompt: str) -> str:
        """Generate a response from the LLM.
        
        Args:
            prompt: Input prompt for the LLM
            
        Returns:
            Generated response text
        """
        if not self.model or not self.tokenizer:
            raise RuntimeError("Model not loaded")
        
        # Tokenize and generate
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=self.config.get("max_tokens", 200),
                temperature=self.config.get("temperature", 0.7),
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        response_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        response_text = response_text.split("<|assistant|>")[-1].strip()
        
        return response_text
    
    def parse_json_response(self, response_text: str, fallback_func=None, *fallback_args) -> Dict[str, Any]:
        """Parse JSON response with fallback.
        
        Args:
            response_text: Response text from LLM
            fallback_func: Function to call if JSON parsing fails
            *fallback_args: Arguments for fallback function
            
        Returns:
            Parsed JSON dictionary
        """
        try:
            return json.loads(response_text)
        except json.JSONDecodeError:
            if fallback_func:
                self.log("Failed to parse JSON, using fallback")
                return fallback_func(*fallback_args)
            else:
                self.log("Failed to parse JSON, returning empty dict")
                return {}
    
    def build_prompt(self, user_input: str, context: str = "") -> str:
        """Build a formatted prompt for the LLM.
        
        Args:
            user_input: User's input/question
            context: Optional context to include
            
        Returns:
            Formatted prompt string
        """
        system_prompt = self.config.get("system_prompt", "")
        
        prompt = f"""<|system|>
{system_prompt}
<|user|>
{user_input}
{context}
<|assistant|>
"""
        return prompt
