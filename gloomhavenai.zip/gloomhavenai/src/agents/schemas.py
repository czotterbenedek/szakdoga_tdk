"""
Agent configuration schemas using Pydantic and TypedDict.
"""
from pydantic import BaseModel, Field
from typing import Literal, Optional, List, TypedDict
from enum import Enum


class RuleCategory(str, Enum):
    """Categories for rulebook aspects."""
    BOARD_GAME_SETUP = "BoardGameSetup"
    COMBAT = "Combat"
    SCENARIO = "Scenario"
    CHARACTER = "Character"
    IRRELEVANT = "Irrelevant"


class AgentConfig(BaseModel):
    """Base configuration for agents."""
    name: str
    model: str = "gpt-3.5-turbo"
    temperature: float = 0.7
    max_tokens: int = 500
    system_prompt: str


class SupervisorConfig(AgentConfig):
    """Configuration for Supervisor Agent."""
    name: str = "supervisor"
    relevance_threshold: float = 0.5


class SummaryConfig(AgentConfig):
    """Configuration for Summary Agent."""
    name: str = "summary"
    include_sources: bool = True


class AgentState(TypedDict):
    """State passed between agents in the graph (must be TypedDict for LangGraph)."""
    user_question: str
    is_relevant: bool
    category: str
    retrieved_chunks: List[str]
    explanation: str
    is_played_correctly: Optional[bool]
    sources: List[str]
    current_agent: str
    confidence: Optional[float]
    needs_clarification: bool
    clarification_prompt: Optional[str]
    chunks_sufficient: bool
    verification_score: Optional[float]
    web_content: List[str]
    answer_source: str


class StructuredAnswer(BaseModel):
    """Final structured answer to return to user."""
    explanation: str = Field(description="Detailed explanation based on rules")
    is_played_correctly: Optional[bool] = Field(description="Whether the action was correct")
    category: RuleCategory = Field(description="Relevant rulebook category")
    sources: List[str] = Field(default_factory=list, description="Source chunks used")
    
    class Config:
        use_enum_values = True

