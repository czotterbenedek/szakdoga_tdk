import yaml
from typing import List
from llama_index.core import VectorStoreIndex

from src.agents.base_agent import BaseAgent
from src.agents.schemas import AgentState

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)


class RetrieverAgent(BaseAgent):
    """Retriever agent that fetches relevant chunks from the vector store."""
    
    def __init__(self, index: VectorStoreIndex, top_k: int = None):
        """Initialize the retriever agent.
        
        Args:
            index: LlamaIndex VectorStoreIndex for similarity search
            top_k: Number of top chunks to retrieve (defaults to config value)
        """
        if top_k is None:
            top_k = CONFIG['retriever']['top_k']
        # Use a minimal config since retriever doesn't need YAML config
        self.config = {"name": "retriever"}
        self.agent_name = "Retriever"
        self.index = index
        self.top_k = top_k
        self.retriever = index.as_retriever(similarity_top_k=top_k)
    
    def process(self, state: AgentState) -> AgentState:
        """Alias for retrieve to match base class interface."""
        return self.retrieve(state)
        
    def retrieve(self, state: AgentState) -> AgentState:
        """Retrieve relevant chunks based on the user's question.
        
        Args:
            state: Current agent state containing user_question
            
        Returns:
            Updated state with retrieved_chunks field
        """
        user_question = state["user_question"]
        
        # Retrieve chunks using the retriever
        nodes = self.retriever.retrieve(user_question)
        
        # Extract text from nodes
        chunks = [node.text for node in nodes]
        
        state["retrieved_chunks"] = chunks
        state["current_agent"] = "retriever"
        
        return state
