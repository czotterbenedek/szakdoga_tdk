import yaml
from typing import TypedDict
from pathlib import Path
import json
from datetime import datetime
from langgraph.graph import StateGraph, END
from llama_index.core import VectorStoreIndex

from src.agents.schemas import AgentState, StructuredAnswer
from src.agents.supervisor import SupervisorAgent
from src.agents.retriever import RetrieverAgent
from src.agents.verifier import VerifierAgent
from src.agents.webscraper import WebScraperAgent
from src.agents.summary import SummaryAgent

# Load global configuration
with open("conf/config.yaml", 'r') as f:
    CONFIG = yaml.safe_load(f)


class GloomhavenRulesGraph:
    """LangGraph workflow for answering Gloomhaven rules questions."""
    
    def __init__(self, index: VectorStoreIndex):
        """Initialize the graph with all agents.
        
        Args:
            index: VectorStoreIndex for document retrieval
        """
        self.supervisor = SupervisorAgent()
        self.retriever = RetrieverAgent(index)
        self.verifier = VerifierAgent()
        self.webscraper = WebScraperAgent()
        self.summary = SummaryAgent()
        
        # Build the graph
        self.graph = self._build_graph()
        
        # Create output directory for logs
        self.logs_dir = Path(CONFIG['paths']['logs_dir'])
        self.logs_dir.mkdir(exist_ok=True)
        
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow.
        
        Returns:
            Compiled StateGraph
        """
        # Create graph with AgentState
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("supervisor", self.supervisor.analyze_question)
        workflow.add_node("retriever", self.retriever.retrieve)
        workflow.add_node("verifier", self.verifier.verify_chunks)
        workflow.add_node("webscraper", self.webscraper.search_web)
        workflow.add_node("summary", self.summary.generate_answer)
        
        # Set entry point
        workflow.set_entry_point("supervisor")
        
        # Add conditional edge from supervisor
        workflow.add_conditional_edges(
            "supervisor",
            self.supervisor.should_retrieve,
            {
                "retriever": "retriever",
                "summary": "summary"
            }
        )
        
        # Add edge from retriever to verifier
        workflow.add_edge("retriever", "verifier")
        
        # Add conditional edge from verifier
        workflow.add_conditional_edges(
            "verifier",
            self.verifier.should_search_web,
            {
                "summary": "summary",
                "webscraper": "webscraper"
            }
        )
        
        # Add edge from webscraper to summary
        workflow.add_edge("webscraper", "summary")
        
        # Add edge from summary to end
        workflow.add_edge("summary", END)
        
        # Compile the graph
        return workflow.compile()
    
    def query(self, question: str) -> StructuredAnswer:
        """Process a user question through the graph.
        
        Args:
            question: User's question about Gloomhaven rules
            
        Returns:
            StructuredAnswer with explanation, correctness, category, and sources
        """
        # Initialize state
        initial_state: AgentState = {
            "user_question": question,
            "is_relevant": False,
            "category": "Irrelevant",
            "retrieved_chunks": [],
            "explanation": "",
            "is_played_correctly": None,
            "sources": [],
            "current_agent": "",
            "confidence": None,
            "needs_clarification": False,
            "clarification_prompt": None,
            "chunks_sufficient": False,
            "verification_score": None,
            "web_content": [],
            "answer_source": "rulebook"
        }
        
        final_state = self.graph.invoke(initial_state)
        answer = self.summary.format_output(final_state)
        self._save_answer_log(question, answer)
        
        return answer
    
    def _save_answer_log(self, question: str, answer: StructuredAnswer):
        """Save question and answer to JSON log file.
        
        Args:
            question: User's question
            answer: Structured answer from the system
        """
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "question": question,
            "answer": {
                "explanation": answer.explanation,
                "is_played_correctly": answer.is_played_correctly,
                "category": answer.category.value if hasattr(answer.category, 'value') else str(answer.category),
                "sources": answer.sources
            }
        }
        
        # Append to log file
        log_file = self.logs_dir / CONFIG['logging']['answer_log_file']
        
        # Load existing logs or create new list
        if log_file.exists():
            with open(log_file, 'r', encoding='utf-8') as f:
                try:
                    logs = json.load(f)
                except json.JSONDecodeError:
                    logs = []
        else:
            logs = []
        
        # Append new entry
        logs.append(log_entry)
        
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(logs, f, indent=2, ensure_ascii=False)
    
    def save_graph_image(self, output_path: str = "docs/agent_graph.png"):
        """Save a visualization of the graph as a PNG image.
        
        Args:
            output_path: Path where the PNG image will be saved
        """
        try:
            # Create output directory if needed
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Get the graph PNG representation
            png_data = self.graph.get_graph().draw_mermaid_png()
            
            # Save to file
            with open(output_path, 'wb') as f:
                f.write(png_data)
            
            print(f"✓ Graph visualization saved to: {output_path}")
            return output_path
            
        except Exception as e:
            print(f"✗ Error saving graph visualization: {e}")
            print("Note: You may need to install graphviz: pip install pygraphviz")
            return None

