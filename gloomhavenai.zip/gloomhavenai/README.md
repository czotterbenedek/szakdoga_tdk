# Gloomhaven Rules Agent

An AI-powered multi-agent system for answering Gloomhaven board game rules questions using RAG (Retrieval-Augmented Generation) with local LLM models.

## Project Architecture

The system implements a **5-agent orchestration pipeline** using LangGraph for workflow management:

```mermaid
graph TD
    Start([User Question]) --> Supervisor{Supervisor<br/>Classify & Route}
    Supervisor -->|Relevant| Retriever[Retriever<br/>FAISS Search]
    Supervisor -->|Irrelevant/Low Confidence| Summary[Summary<br/>Generate Answer]
    Retriever --> Verifier{Verifier<br/>Quality Check}
    Verifier -->|Sufficient| Summary
    Verifier -->|Insufficient| WebScraper[WebScraper<br/>Web Search]
    WebScraper --> Summary
    Summary --> End([Structured Answer])
    
    style Supervisor fill:#e1f5ff,stroke:#333,stroke-width:2px,color:#000
    style Retriever fill:#fff4e1,stroke:#333,stroke-width:2px,color:#000
    style Verifier fill:#ffe1f5,stroke:#333,stroke-width:2px,color:#000
    style WebScraper fill:#e1ffe1,stroke:#333,stroke-width:2px,color:#000
    style Summary fill:#f5e1ff,stroke:#333,stroke-width:2px,color:#000
```

### Agent Responsibilities

#### 1. Supervisor Agent
**Role:** Question classification and relevance determination

- Analyzes incoming user questions for relevance to Gloomhaven rules
- Classifies questions into categories: BoardGameSetup, Combat, Scenario, Character, or Irrelevant
- Implements confidence-based routing
- Requests user clarification when confidence is low
- Uses keyword-based fallback classification when LLM parsing fails

#### 2. Retriever Agent
**Role:** Document retrieval from vector store

- Retrieves information from FAISS vector store using similarity search


#### 3. Verifier Agent
**Role:** Quality control for retrieved information

- Verifies whether the retrieved chunks are relevant to the users question. If yes, it calls the summary agent, if not, it calls the WebScraper agent.

#### 4. WebScraper Agent
**Role:** Internet search fallback mechanism

- Searches Gloomhaven related information on the Internet on possible valid web pages


#### 5. Summary Agent
**Role:** Structured answer generation

- Generates final structured answers with three components:
  - **Explanation:** Detailed rule explanation based on retrieved context
  - **Correctness validation:** Boolean indicating if scenario was played correctly (nullable for non-validatable questions)
  - **Category:** Classification of rule type

### Technology Stack

**LLM & Embeddings:**
- TinyLlama-1.1B-Chat for all LLM-based agents (CPU-compatible)
- Qwen/Qwen3-Embedding-0.6B for document embeddings

**RAG Infrastructure:**
- LlamaIndex for document loading and semantic chunking
- FAISS IndexFlatL2 for vector similarity search
- SemanticSplitterNodeParser for intelligent chunk boundaries

**Agent Orchestration:**
- LangGraph StateGraph for workflow management
- Conditional routing based on confidence, quality, and relevance

**Utility Libraries:**
- PyYAML for configuration management
- Pydantic for data validation
- BeautifulSoup4 for web scraping
- Requests for HTTP operations

## Evaluation

Everything was logged with mlflow. Below are screenshots about results from mlflow ui.

![result_1](./docs/eval_results/mlflow_1.png)
![result_2](./docs/eval_results/mlflow_2.png)



## Future Improvements

### 1. Data Processing & Knowledge Base
- **Data preparation:** Improve data preprocessing by cleaning the text of non-alphanumeric characters, HTML tags, and other irrelevant artifacts.
- **Visual rules handling:** Extract images, diagrams, and symbols from the PDF to support rule explanations.  
- **Enhanced semantic chunking:** Implement hierarchical chunking (section → subsection → paragraph) with overlap to capture exceptions and edge cases.  
- **Metadata enrichment:** Store additional metadata per chunk, such as page numbers, section titles, character references, and exceptions, to improve citation accuracy and context.  
- **Cloud-based storage & scalability:** Move FAISS to a cloud environment (e.g., Databricks) for faster retrieval.

### 2. Model & Embeddings
- **Upgrade embeddings:** Use larger or domain-adapted embedding models for better semantic matching.  
- **Adaptive LLM selection:** Use lightweight models for classification or clarification prompts, and larger models for explanation generation.  

### 3. Agentic Workflow & Reliability
- **Evaluation framework:** Add automated tests for agents, validating answers against known FAQs.
- **Evaluation:** Extend the evaluation framework to assess inter-agent communication. Verify what information is passed through spans and traces, and confirm that the appropriate agent is invoked for a given user input. Additionally, evaluate the alignment between the expected and the predicted answer text.
- **Confidence calibration:** Use the Verifier Agent to produce confidence scores and fallback strategies more systematically.  
- **Feedback loop:** Allow users to flag incorrect answers, and store these question-answer pairs for future refinement of the system.


