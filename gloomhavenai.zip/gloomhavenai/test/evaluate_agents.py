"""
Evaluation workflow for Gloomhaven Rules Agent system.
Processes evaluation_dataset.yaml, runs inference, compares results, and logs with MLflow.
"""
import os
import sys
import yaml
import json
import mlflow
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Tuple

sys.path.insert(0, os.path.abspath('.'))

from src.main import initialize_system
from src.agents.graph import GloomhavenRulesGraph


class AgentEvaluator:
    """Evaluates the Gloomhaven Rules Agent system against ground truth data."""
    
    def __init__(self, dataset_path: str = "data/evaluation_dataset.yaml"):
        """
        Initialize the evaluator.
        
        Args:
            dataset_path: Path to evaluation dataset YAML file
        """
        self.dataset_path = dataset_path
        self.evaluation_data = self._load_evaluation_data()
        self.results = []
        
    def _load_evaluation_data(self) -> List[Dict[str, Any]]:
        """Load evaluation dataset from YAML file."""
        with open(self.dataset_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return data['evaluation_data']
    
    def _compare_answers(
        self, 
        predicted: Dict[str, Any], 
        expected: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Compare predicted answer with expected answer.
        
        Args:
            predicted: Generated answer from the system
            expected: Ground truth answer
            
        Returns:
            Comparison metrics dictionary
        """
        category_match = predicted['category'] == expected['category']
        
        expected_correctness = expected.get('is_played_correctly')
        predicted_correctness = predicted.get('is_played_correctly')
        
        if expected_correctness is None:
            correctness_match = True
            correctness_applicable = False
        else:
            correctness_match = predicted_correctness == expected_correctness
            correctness_applicable = True
        
        overall_match = category_match and correctness_match
        
        return {
            'category_match': category_match,
            'correctness_match': correctness_match,
            'correctness_applicable': correctness_applicable,
            'overall_match': overall_match,
            'expected_category': expected['category'],
            'predicted_category': predicted['category'],
            'expected_correctness': expected_correctness,
            'predicted_correctness': predicted_correctness
        }
    
    def evaluate_single_question(
        self, 
        question_data: Dict[str, Any], 
        graph: GloomhavenRulesGraph
    ) -> Dict[str, Any]:
        """
        Evaluate a single question.
        
        Args:
            question_data: Question and expected answer data
            graph: Initialized GloomhavenRulesGraph instance
            
        Returns:
            Evaluation result dictionary
        """
        question_id = question_data['id']
        question_text = question_data['question']
        expected_answer = question_data['expected_answer']
        
        try:
            answer = graph.query(question_text)
            
            predicted_answer = {
                'explanation': answer.explanation,
                'is_played_correctly': answer.is_played_correctly,
                'category': answer.category.value if hasattr(answer.category, 'value') else str(answer.category),
                'sources': answer.sources
            }
            
            comparison = self._compare_answers(predicted_answer, expected_answer)
            
            result = {
                'id': question_id,
                'question': question_text,
                'predicted_answer': predicted_answer,
                'expected_answer': expected_answer,
                'comparison': comparison,
                'status': 'success'
            }
            
        except Exception as e:
            result = {
                'id': question_id,
                'question': question_text,
                'status': 'error',
                'error_message': str(e)
            }
        
        return result
    
    def calculate_metrics(self) -> Dict[str, float]:
        """
        Calculate overall evaluation metrics.
        
        Returns:
            Dictionary with accuracy metrics
        """
        successful_results = [r for r in self.results if r['status'] == 'success']
        
        if not successful_results:
            return {
                'total_questions': len(self.results),
                'successful_evaluations': 0,
                'failed_evaluations': len(self.results),
                'category_accuracy': 0.0,
                'correctness_accuracy': 0.0,
                'overall_accuracy': 0.0
            }
        
        category_correct = sum(
            1 for r in successful_results 
            if r['comparison']['category_match']
        )
        
        correctness_applicable = [
            r for r in successful_results 
            if r['comparison']['correctness_applicable']
        ]
        
        if correctness_applicable:
            correctness_correct = sum(
                1 for r in correctness_applicable 
                if r['comparison']['correctness_match']
            )
            correctness_accuracy = (correctness_correct / len(correctness_applicable)) * 100
        else:
            correctness_correct = 0
            correctness_accuracy = 0.0
        
        overall_correct = sum(
            1 for r in successful_results 
            if r['comparison']['overall_match']
        )
        
        category_accuracy = (category_correct / len(successful_results)) * 100
        overall_accuracy = (overall_correct / len(successful_results)) * 100
        
        metrics = {
            'total_questions': len(self.results),
            'successful_evaluations': len(successful_results),
            'failed_evaluations': len(self.results) - len(successful_results),
            'category_accuracy': category_accuracy,
            'correctness_accuracy': correctness_accuracy,
            'overall_accuracy': overall_accuracy,
            'category_correct': category_correct,
            'correctness_correct': correctness_correct,
            'overall_correct': overall_correct
        }
        
        category_breakdown = {}
        for r in successful_results:
            cat = r['expected_answer']['category']
            if cat not in category_breakdown:
                category_breakdown[cat] = {'total': 0, 'correct': 0}
            category_breakdown[cat]['total'] += 1
            if r['comparison']['category_match']:
                category_breakdown[cat]['correct'] += 1
        
        for cat, stats in category_breakdown.items():
            acc = (stats['correct'] / stats['total']) * 100
            metrics[f'category_{cat}_accuracy'] = acc
        
        return metrics
    
    def run_evaluation(
        self, 
        graph: GloomhavenRulesGraph,
        experiment_name: str = "gloomhaven_agent_evaluation"
    ) -> Dict[str, Any]:
        """
        Run full evaluation workflow with MLflow logging.
        
        Args:
            graph: Initialized GloomhavenRulesGraph instance
            experiment_name: MLflow experiment name
            
        Returns:
            Evaluation results and metrics
        """
        mlflow.set_experiment(experiment_name)
        
        with mlflow.start_run(run_name=f"eval_{datetime.now().strftime('%Y%m%d_%H%M%S')}"):
            mlflow.log_param("dataset_path", self.dataset_path)
            mlflow.log_param("total_questions", len(self.evaluation_data))
            mlflow.log_param("timestamp", datetime.now().isoformat())
            
            print(f"Starting evaluation on {len(self.evaluation_data)} questions...")
            print("=" * 70)
            
            for i, question_data in enumerate(self.evaluation_data, 1):
                print(f"\n[{i}/{len(self.evaluation_data)}] Evaluating question {question_data['id']}...")
                
                result = self.evaluate_single_question(question_data, graph)
                self.results.append(result)
                
                if result['status'] == 'success':
                    comp = result['comparison']
                    status_symbol = "✓" if comp['overall_match'] else "✗"
                    print(f"{status_symbol} Category: {comp['predicted_category']} (expected: {comp['expected_category']})")
                    print(f"{status_symbol} Correctness: {comp['predicted_correctness']} (expected: {comp['expected_correctness']})")
                else:
                    print(f"✗ Error: {result['error_message']}")
                
                mlflow.log_metric(f"question_{question_data['id']}_success", 1 if result['status'] == 'success' else 0)
                
            print("\n" + "=" * 70)
            print("Calculating metrics...")
            
            metrics = self.calculate_metrics()
            
            for metric_name, metric_value in metrics.items():
                if isinstance(metric_value, (int, float)):
                    mlflow.log_metric(metric_name, metric_value)
            
            results_path = f"evaluation_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            results_full_path = Path("test") / "results" / results_path
            results_full_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(results_full_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'metrics': metrics,
                    'results': self.results,
                    'timestamp': datetime.now().isoformat()
                }, f, indent=2, ensure_ascii=False)
            
            mlflow.log_artifact(str(results_full_path))
            
            self._print_summary(metrics)
            
            print(f"\n✓ Results saved to: {results_full_path}")
            print(f"✓ MLflow experiment: {experiment_name}")
            
            return {
                'metrics': metrics,
                'results': self.results
            }
    
    def _print_summary(self, metrics: Dict[str, float]):
        """Print evaluation summary."""
        print("\n" + "=" * 70)
        print("EVALUATION SUMMARY")
        print("=" * 70)
        print(f"\nTotal Questions: {metrics['total_questions']}")
        print(f"Successful Evaluations: {metrics['successful_evaluations']}")
        print(f"Failed Evaluations: {metrics['failed_evaluations']}")
        print(f"\n{'─' * 70}")
        print("ACCURACY METRICS")
        print(f"{'─' * 70}")
        print(f"Category Classification Accuracy: {metrics['category_accuracy']:.2f}%")
        print(f"Correctness Prediction Accuracy:  {metrics['correctness_accuracy']:.2f}%")
        print(f"Overall Accuracy (Both Correct):  {metrics['overall_accuracy']:.2f}%")
        print(f"{'─' * 70}")
        
        print("\nCategory Breakdown:")
        for key, value in metrics.items():
            if key.startswith('category_') and key.endswith('_accuracy') and 'category_accuracy' != key:
                category_name = key.replace('category_', '').replace('_accuracy', '')
                print(f"  {category_name:20s}: {value:.2f}%")
        
        print("=" * 70)


def main():
    """Main evaluation entry point."""
    print("=" * 70)
    print("GLOOMHAVEN RULES AGENT - EVALUATION WORKFLOW")
    print("=" * 70)
    
    print("\n[1/3] Initializing system...")
    index = initialize_system(force_rebuild=False)
    graph = GloomhavenRulesGraph(index)
    print("✓ System initialized")
    
    print("\n[2/3] Setting up MLflow...")
    mlflow.set_tracking_uri("file:./mlruns")
    print("✓ MLflow tracking URI set to: ./mlruns")
    
    print("\n[3/3] Running evaluation...")
    evaluator = AgentEvaluator()
    results = evaluator.run_evaluation(graph)
    
    print("\n" + "=" * 70)
    print("✓ EVALUATION COMPLETE")
    print("=" * 70)
    print("\nTo view MLflow results, run:")
    print("  mlflow ui")
    print("\nThen open: http://localhost:5000")
    
    return results


if __name__ == "__main__":
    main()
